function portfolioPage() {
  return (
    <div>
      <h1>The Portfolio Page</h1>
    </div>
  );
}
export default portfolioPage;
//localhost:3000/portfolio --- route to render this component
