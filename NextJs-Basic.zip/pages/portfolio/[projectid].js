import { useRouter } from 'next/router';

function PortfolioProductPage() {
  const router = useRouter();
  console.log(router.pathname);
  console.log('query', router.query);

  //send a http req to the backend server
  //to fetch the data with projectid by router.query.projectid
  return (
    <div>
      <h1>The Portfolio Product Page</h1>
    </div>
  );
}
export default PortfolioProductPage;
// /portfolio/anything -- we get access to this page but not /list as it is already defined
// router.query gives us the access to the data encoded in URL--- to get access to the concrete value encoded in the URL.
