import Link from 'next/link';
function ClientsPage() {
  const clients = [
    { id: 'maxi', name: 'Maximilian' },
    { id: 'manu', name: 'Manuel' },
  ];
  return (
    <div>
      <h1>The Clients Page</h1>
      {clients.map((client) => (
        <li key={client.id}>
          {/* <Link href={`/clients/${client.id}`}>{client.name}</Link> */}
          {/* instead of writing strings in the link route path */}
          <Link
            href={{
              pathname: '/clients/[id]',
              query: { id: client.id },
            }}
          >
            {client.name}
          </Link>
        </li>
      ))}
      {/* Implementing dynamically */}
      {/* <ul>
        <li>
          <Link href='/clients/maxi'>Maximilian</Link>
        </li>
        <li>
          <Link href='/clients/manu'>Manuel</Link>
        </li>
      </ul> */}
    </div>
  );
}
export default ClientsPage;
// here clients page accessed from main index.js and in order to access dynamic routes here we need to add links both the above links going to same page but id is changing by query
