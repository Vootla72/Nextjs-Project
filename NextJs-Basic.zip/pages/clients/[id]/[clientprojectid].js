import { useRouter } from 'next/router';
function SelectedClientProjectPage() {
  const router = useRouter();
  console.log('selectedClient', router.query); //Gets object of two properties one is for [id] as it is dynamic and another for this component
  return (
    <div>
      <h1>The Project Page for a Specific Project for a Selected Client</h1>
    </div>
  );
}
export default SelectedClientProjectPage;
//clients/1/2
