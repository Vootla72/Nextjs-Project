import { useRouter } from 'next/router';
function ClientProjectsPage() {
  const router = useRouter();
  console.log('id index', router.query); // only id has an access
  function loadProjecthandler() {
    //...load data; push is a method on router just acting as a link
    router.push('/clients/maxi/projecta');
    // router.replace('/clients/maxi/projecta'); we cant come to previous page it was overridden by current page

    //alternative for data passing in roter.push
    // router.push({
    //   pathname: '/clients/[id]/[clientprojectid]',
    //   query: {
    //     id: 'maxi',
    //     clientprojectid: 'projecta',
    //   },
    // });
  }
  return (
    <div>
      <h1>The Projects of a Given Client</h1>
      {/* to navigate to a link when some action completed */}
      <button onClick={loadProjecthandler}>Load Project A</button>
    </div>
  );
}
export default ClientProjectsPage;
// clients/1
