import { useRouter } from 'next/router';
function BlogPostsPage() {
  const router = useRouter();
  console.log('Blog posts', router.query);
  return (
    <div>
      <h1>The Blog Posts</h1>
    </div>
  );
}
export default BlogPostsPage;
//[...slug] => to render this component for all the cases
// (a)/blog/2020/12 - router.query: array of 2 elememts slug:['2020,'12']
// (b)/blog/2020/12/theIdOfBlog - - router.query: array of 3 strings slug:['2020,'12',theIdOfBlog]
