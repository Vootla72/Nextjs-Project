// const { Component } = React,
//   { render } = ReactDOM,
//   { Form, Input, Button } = semanticUIReact;
// import react from "react";
import React from 'react';
//   import {Form,Input,Button} from react

// const rootNode = document.getElementById('root');

class App extends React {
  state = {
    submitAttempted: false,
    isValid: {
      contactName: false,
      contactPhone: false,
      contactMail: false,
    },
  };

  validateInput = (name, value) => {
    switch (name) {
      case 'contactName': {
        if (/^[A-Z][a-z]+$/.test(value)) {
          return true;
        } else return false;
      }
      case 'contactPhone': {
        if (/^\d+$/.test(value)) {
          return true;
        } else return false;
      }
      case 'contactMail': {
        if (/^\w+@\w+\.\w{1,4}$/i.test(value)) {
          return true;
        } else return false;
      }
      default:
        return false;
    }
  };

  onChange = ({ target: { name, value } }) =>
    this.setState({
      [name]: value,
      isValid: {
        ...this.state.isValid,
        [name]: this.validateInput(name, value),
      },
    });

  onSubmit = (e) => {
    e.preventDefault();
    this.setState({
      submitAttempted: true,
    });
    Object.values(this.state.isValid).every(Boolean) &&
      console.log(
        this.state.contactName,
        this.state.contactPhone,
        this.state.contactMail
      );
  };

  render() {
    return (
      <Form onSubmit={this.onSubmit}>
        <Form.Field
          name='contactName'
          className=''
          control={Input}
          label='Contact Name'
          placeholder='Contact Name'
          value={this.state.contactName || ''}
          onChange={this.onChange}
          required
          error={
            this.state.submitAttempted &&
            !this.state.isValid.contactName && {
              content:
                'Valid contact name should contain upper-case letters followed by lower-case letters',
              pointing: 'below',
            }
          }
        />
        <Form.Field
          name='contactPhone'
          className=''
          control={Input}
          label='Contact Phone'
          placeholder='Contact Phone'
          value={this.state.contactPhone || ''}
          onChange={this.onChange}
          required
          error={
            this.state.submitAttempted &&
            !this.state.isValid.contactPhone && {
              content: 'Valid phone, should contain numbers only',
              pointing: 'below',
            }
          }
        />
        <Form.Field
          name='contactMail'
          className=''
          control={Input}
          label='Contact Mail'
          placeholder='example@hello.com'
          value={this.state.contactMail || ''}
          onChange={this.onChange}
          required
          error={
            this.state.submitAttempted &&
            !this.state.isValid.contactMail && {
              content: 'Valid e-mail format should be fulfilled',
              pointing: 'below',
            }
          }
        />
        <Button
          type='submit'
          disabled={
            this.state.submitAttempted &&
            !Object.values(this.state.isValid).every(Boolean)
          }
        >
          Submit
        </Button>
      </Form>
    );
  }
}
