function AboutPage() {
  return (
    <div>
      <h1>The About Page</h1>
    </div>
  );
}
export default AboutPage;
//Here file name used as route path .. localhost:3000/about (directly file or folder with index.js)
