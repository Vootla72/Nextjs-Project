import Link from 'next/link';
function HomePage() {
  return (
    <div>
      <h1>The Home Page</h1>
      {/* Navigating to the above creating pages automatically */}
      <ul>
        <li>
          <Link href='/portfolio'>Portfolio</Link>
        </li>
        <li>
          <Link href='/clients'>Clients</Link>
        </li>
      </ul>
    </div>
  );
}
export default HomePage;

//npm run dev creates .next folder. ntg to do with this
//drawback of anchor tag:It sends a brand new HTTP request tothe server so the state will be lost   <a href='/portfolio'>Portfolio</a>
//With Link we will naviagate to the page withut losing App state mgmt and nt sending a new request
